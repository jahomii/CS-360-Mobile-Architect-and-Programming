package com.example.mobile2appinventory.ui.login;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;

import androidx.annotation.Nullable;

/***************************************
 * INVENTORY DATABASE
 * inventory information is stored here
 **************************************/

public class InventoryDatabase  extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "totalStock.db";
    private static final int DATABASE_VERSION = 1;

    // table names and columns
    public static final String TABLE_NAME = "inventory";
    public static final String COLUMN_ID = BaseColumns._ID;
    public static final String COLUMN_TITLE = "title";
    public static final String COLUMN_INFO = "info";
    public static final String COLUMN_STOCK= "stock";

    // SQL query to create the table
    private static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE " + TABLE_NAME + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    COLUMN_TITLE + " TEXT," +
                    COLUMN_INFO + " TEXT," +
                    COLUMN_STOCK + " INTEGER)";
    // SQL query to delete the table
    private static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + TABLE_NAME;

    // constructor
    public InventoryDatabase(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_ENTRIES);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(SQL_DELETE_ENTRIES);
        onCreate(db);
    }
}
