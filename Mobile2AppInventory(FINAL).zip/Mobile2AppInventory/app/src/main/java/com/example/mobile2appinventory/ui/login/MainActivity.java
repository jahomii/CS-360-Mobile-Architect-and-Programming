package com.example.mobile2appinventory.ui.login;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Typeface;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import com.example.mobile2appinventory.R;

public class MainActivity extends AppCompatActivity {

    TextView itemTitle;
    TextView itemInfo;
    EditText stockCount;
    Button addData;
    LinearLayout itemsListLayout;
    InventoryDatabase dbHelper;
    UserDatabase dbHelperPhone;

    private int SMS_PERMISSION_CODE = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new InventoryDatabase(this);
        dbHelperPhone = new UserDatabase(this);

        // Initialize views
        itemTitle = findViewById(R.id.itemTitle);
        itemInfo = findViewById(R.id.itemInfo);
        stockCount = findViewById(R.id.stockCount);
        addData = findViewById(R.id.addData);
        itemsListLayout = findViewById(R.id.itemsListLayout);

        // Handle addData button click
        addData.setOnClickListener(v -> {
            String titleInput = itemTitle.getText().toString();
            String itemInput = itemInfo.getText().toString();
            String stockInputString = stockCount.getText().toString();

            // Check if stock input is empty or invalid
            if (titleInput.isEmpty() || itemInput.isEmpty() || stockInputString.isEmpty()) {
                Toast.makeText(MainActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // Check if the stock input is a valid number
            if (TextUtils.isDigitsOnly(stockInputString)) {
                int stockInput = Integer.parseInt(stockInputString);

                // Add the data to the database
                if (addDataToDatabase(titleInput, itemInput, stockInput)) {
                    Toast.makeText(MainActivity.this, "Item Added!", Toast.LENGTH_SHORT).show();

                    // Clear input fields after adding the item
                    itemTitle.setText("");
                    itemInfo.setText("");
                    stockCount.setText("");

                    // Update the UI with the new data
                    displayItems();
                } else {
                    Toast.makeText(MainActivity.this, "Error Adding Item. Try Again.", Toast.LENGTH_SHORT).show();
                }
            } else {
                // If the stock input is not a valid number
                Toast.makeText(MainActivity.this, "Invalid stock count. Please enter a valid number.", Toast.LENGTH_SHORT).show();
            }
        });

        displayItems();
    }

    /***************************************
     * ADD DATA TO THE DATABASE
     * method to create new entries to
     * the database
     **************************************/
    private boolean addDataToDatabase(String itemTitle, String itemInfo, int stockCount) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        // Insert new item
        ContentValues values = new ContentValues();
        values.put(InventoryDatabase.COLUMN_TITLE, itemTitle);
        values.put(InventoryDatabase.COLUMN_INFO, itemInfo);
        values.put(InventoryDatabase.COLUMN_STOCK, stockCount);

        long newRowId = db.insert(InventoryDatabase.TABLE_NAME, null, values);
        db.close();  // Close the database connection
        return newRowId != -1;
    }

    /***************************************
     * DISPLAY ITEMS
     * method to display all items and their
     * information publicly
     **************************************/
    private void displayItems() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(
                InventoryDatabase.TABLE_NAME, null, null, null, null, null, null                            // The sort order
        );

        itemsListLayout.removeAllViews();

        // Iterate through the cursor and add a TextView and buttons for each item
        while (cursor.moveToNext()) {
            @SuppressLint("Range") final String title = cursor.getString(cursor.getColumnIndex(InventoryDatabase.COLUMN_TITLE));
            @SuppressLint("Range") final String info = cursor.getString(cursor.getColumnIndex(InventoryDatabase.COLUMN_INFO));
            @SuppressLint("Range") final int stock = cursor.getInt(cursor.getColumnIndex(InventoryDatabase.COLUMN_STOCK));
            @SuppressLint("Range") final long itemId = cursor.getLong(cursor.getColumnIndex(InventoryDatabase.COLUMN_ID));

            // Create a new LinearLayout to hold each item view
            LinearLayout itemLayout = new LinearLayout(this);
            itemLayout.setOrientation(LinearLayout.HORIZONTAL);
            itemLayout.setPadding(8, 8, 8, 8);
            itemLayout.setBackgroundColor(getResources().getColor(R.color.white));

            // Create a TextView to display item details
            TextView itemTextView = new TextView(this);
            itemTextView.setText("Title: " + title + "\n Description: " + info + "\nStock: " + stock + "\n");
            itemTextView.setTextSize(16);
            itemTextView.setLayoutParams(new LinearLayout.LayoutParams(1, LinearLayout.LayoutParams.WRAP_CONTENT, 1));


            // add Edit and Delete buttons to each row
            Button editButton = new Button(this);
            editButton.setText("Edit");
            editButton.setTypeface(Typeface.MONOSPACE);
            editButton.setTextColor(getResources().getColor(android.R.color.white));
            editButton.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            editButton.setBackgroundColor(getColor(R.color.blush));
            // handle edit action
            editButton.setOnClickListener(v -> {
                editItem(itemId);
            });

            Button deleteButton = new Button(this);
            deleteButton.setText("Delete");
            itemLayout.setPadding(8, 8, 8, 8);
            deleteButton.setTypeface(Typeface.MONOSPACE);
            deleteButton.setTextColor(getResources().getColor(android.R.color.white));
            deleteButton.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            deleteButton.setBackgroundColor(getColor(R.color.blush));
            // Handle Delete action
            deleteButton.setOnClickListener(v -> {
                deleteItem(itemId);
            });

            // Add TextView and buttons to the item layout
            itemLayout.addView(itemTextView);
            itemLayout.addView(editButton);
            itemLayout.addView(deleteButton);

            // Add the item layout to the parent layout
            itemsListLayout.addView(itemLayout);
        }

        cursor.close();
        db.close(); // Close the database connection
    }

    /***************************************
     * EDIT ITEMS
     * method to edit items already
     * submitted to the database
     **************************************/
    private void editItem(long itemId) {

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(
                InventoryDatabase.TABLE_NAME, null,
                InventoryDatabase.COLUMN_ID + " = ?",
                new String[]{String.valueOf(itemId)},
                null, null, null
        );

        // Retrieve current item details
        if (cursor != null && cursor.moveToFirst()) {
            @SuppressLint("Range") String title = cursor.getString(cursor.getColumnIndex(InventoryDatabase.COLUMN_TITLE));
            @SuppressLint("Range") String info = cursor.getString(cursor.getColumnIndex(InventoryDatabase.COLUMN_INFO));
            @SuppressLint("Range") int stock = cursor.getInt(cursor.getColumnIndex(InventoryDatabase.COLUMN_STOCK));
            cursor.close();

            // Create an AlertDialog to edit the item
            EditText titleEditText = new EditText(this);
            titleEditText.setText(title);
            titleEditText.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

            EditText infoEditText = new EditText(this);
            infoEditText.setText(info);
            infoEditText.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

            EditText stockEditText = new EditText(this);
            stockEditText.setText(String.valueOf(stock));
            stockEditText.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

            // Layout for the edit box
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setPadding(16, 8, 16, 8);
            layout.addView(titleEditText);
            layout.addView(infoEditText);
            layout.addView(stockEditText);

            new android.app.AlertDialog.Builder(this)
                    .setTitle("Edit Item")
                    .setView(layout)
                    .setPositiveButton("Save", (dialog, which) -> {
                        String newTitle = titleEditText.getText().toString();
                        String newInfo = infoEditText.getText().toString();
                        String newStockString = stockEditText.getText().toString();

                        // Check if any field is empty
                        if (newTitle.isEmpty() || newInfo.isEmpty() || newStockString.isEmpty()) {
                            Toast.makeText(MainActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                            return;
                        }

                        // Check if stock is a valid number
                        if (!TextUtils.isDigitsOnly(newStockString)) {
                            Toast.makeText(MainActivity.this, "Invalid stock count. Please enter a valid number.", Toast.LENGTH_SHORT).show();
                            return;
                        }

                        // Convert the stock to an integer
                        int newStock = Integer.parseInt(newStockString);

                        // Update the item in the database
                        if (updateItemInDatabase(itemId, newTitle, newInfo, newStock)) {
                            Toast.makeText(MainActivity.this, "Item Updated!", Toast.LENGTH_SHORT).show();
                            displayItems();  // Refresh the item list
                            if (newStock == 0) {
                                // In SMS_permissions
                                String message = getIntent().getStringExtra("One or more items have depleted in stock");
                                sendSMS(message);
                            }
                        } else {
                            Toast.makeText(MainActivity.this, "Error Updating Item. Try Again.", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        }
    }

    /***************************************
     * UPDATE ITEMS IN THE DATABASE
     * method to submit the updates
     * to the database,
     * used by editItem method
     **************************************/
    private boolean updateItemInDatabase(long itemId, String newTitle, String newInfo, int newStock) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(InventoryDatabase.COLUMN_TITLE, newTitle);
        values.put(InventoryDatabase.COLUMN_INFO, newInfo);
        values.put(InventoryDatabase.COLUMN_STOCK, newStock);

        int rowsUpdated = db.update(
                InventoryDatabase.TABLE_NAME,
                values,
                InventoryDatabase.COLUMN_ID + " = ?",
                new String[]{String.valueOf(itemId)}
        );

        db.close();
        return rowsUpdated > 0;
    }

    /***************************************
     * DELETE ITEMS
     * method to delete the
     * items from the database
     **************************************/
    private void deleteItem(long itemId) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        int rowsDeleted = db.delete(
                InventoryDatabase.TABLE_NAME,
                InventoryDatabase.COLUMN_ID + " = ?",
                new String[]{String.valueOf(itemId)}
        );

        db.close();

        if (rowsDeleted > 0) {
            Toast.makeText(MainActivity.this, "Item Deleted!", Toast.LENGTH_SHORT).show();
            displayItems(); // Refresh the item list
        } else {
            Toast.makeText(MainActivity.this, "Error Deleting Item. Try Again.", Toast.LENGTH_SHORT).show();
        }
    }

    /***************************************
     * SEND SMS
     * Send SMS updates when the stock
     * count reaches 0
     **************************************/
    @SuppressLint("Range")
    public void sendSMS(String message) {
        SQLiteDatabase db = dbHelperPhone.getReadableDatabase();
        Cursor cursor = db.query(
                UserDatabase.TABLE_NAME, new String[]{UserDatabase.COLUMN_PHONE},
                null, null, null, null, null
        );

        String phoneNumber = null;
        if (cursor != null && cursor.moveToFirst()) {
            phoneNumber = cursor.getString(cursor.getColumnIndex(UserDatabase.COLUMN_PHONE));
            cursor.close();
        }

        if (TextUtils.isEmpty(phoneNumber)) {
            Toast.makeText(this, "Phone number is not available.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (checkSelfPermission(android.Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            sendSMSMessage(phoneNumber, message);
        } else {
            Toast.makeText(this, "SMS permissions not granted.", Toast.LENGTH_SHORT).show();
        }
    }

    private void sendSMSMessage(String phoneNumber, String message) {
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(phoneNumber, null, message, null, null);
        Toast.makeText(this, "Message sent successfully.", Toast.LENGTH_SHORT).show();
    }

}
