package com.example.mobile2appinventory.ui.login;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.mobile2appinventory.R;

public class Login extends AppCompatActivity {

    EditText email, password;
    Button registerLogin, submitLogin;
    UserDatabase dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        dbHelper = new UserDatabase(this);

        // Initialize views
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        submitLogin = findViewById(R.id.submitLogin);
        registerLogin = findViewById(R.id.registerLogin);

        //check if SMS permissions have been granted
        int permsForSMS = ContextCompat.checkSelfPermission(Login.this, Manifest.permission.SEND_SMS);

        submitLogin.setOnClickListener(v -> {
            String emailInput = email.getText().toString().trim();
            String passwordInput = password.getText().toString().trim();

            // Validate fields are not empty
            if (emailInput.isEmpty() || passwordInput.isEmpty()) {
                Toast.makeText(Login.this, "Please fill in both email and password.", Toast.LENGTH_SHORT).show();
                return;
            }

            // Validate email + password against info in the database
            if (isValidLogin(emailInput, passwordInput)) {
                Toast.makeText(Login.this, "Login Successful!", Toast.LENGTH_SHORT).show();

                // Check SMS permissions, if not granted navigate to SMS page
                if (permsForSMS != PackageManager.PERMISSION_GRANTED) {
                   Intent intent = new Intent(Login.this, SMS_permissions.class);
                   startActivity(intent);
                   finish();
                } else {
                    // If SMS permission is granted, navigate to MainActivity
                    Intent intent = new Intent(Login.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                }
            } else {
                Toast.makeText(Login.this, "Invalid Email or Password. Try again.", Toast.LENGTH_SHORT).show();
            }
        });

        // Handle register button click
        registerLogin.setOnClickListener(v -> {
            String emailInput = email.getText().toString();
            String passwordInput = password.getText().toString();

            // Check if email already exists
            if (emailExists(emailInput)) {
                Toast.makeText(Login.this, "Email already exists. Try logging in or register a different email.", Toast.LENGTH_SHORT).show();
            } else {
                // Register new user in the database
                if (registerNewUser(emailInput, passwordInput)) {
                    Toast.makeText(Login.this, "User Registration Successful!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(Login.this, SMS_permissions.class);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(Login.this, "Error Registering User. Try again.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    /***************************************
     * LOGIN VALIDATION
     * method to ensure that a user is
     * not logged in unless they input
     * the correct email/password combo
     **************************************/
    private boolean isValidLogin(String email, String password) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(
                UserDatabase.TABLE_NAME, null,
                UserDatabase.COLUMN_EMAIL + " = ? AND " + UserDatabase.COLUMN_PASSWORD + " = ?",
                new String[]{email, password},
                null, null, null
        );

        boolean validLogin = cursor != null && cursor.getCount() > 0;

        // Check if cursor is not null and has valid data
        if (cursor != null) {
            cursor.close();
        }
        return validLogin;
    }

    /***************************************
     * REGISTER NEW USER
     * method to register new users
     * not already found in the database
     **************************************/
    private boolean registerNewUser(String email, String password) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        // Insert new user
        ContentValues values = new ContentValues();
        values.put(UserDatabase.COLUMN_EMAIL, email);
        values.put(UserDatabase.COLUMN_PASSWORD, password);

        long newRowId = db.insert(UserDatabase.TABLE_NAME, null, values);
        return newRowId != -1;
    }

    /***************************************
     * CHECK IF EMAIL EXISTS
     * method to check for pre-existing
     * emails in the database
     **************************************/
    private boolean emailExists(String email) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(
                UserDatabase.TABLE_NAME,
                null,
                UserDatabase.COLUMN_EMAIL + " = ?",
                new String[]{email},
                null, null, null
        );

        boolean emailExists = cursor != null && cursor.getCount() > 0;

        // Check if cursor is not null and contains a result
        if (cursor != null) {
            cursor.close();
        }
        return emailExists;
    }
}
