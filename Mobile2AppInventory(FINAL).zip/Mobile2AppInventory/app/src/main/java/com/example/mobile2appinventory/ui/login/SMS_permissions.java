package com.example.mobile2appinventory.ui.login;

import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.Manifest;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.mobile2appinventory.R;

public class SMS_permissions extends AppCompatActivity {

    EditText phoneInput;
    Button submitButton, noSMSButton;

    InventoryDatabase dbHelper;
    UserDatabase dbHelperPhone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permissions);

        dbHelper = new InventoryDatabase(this);
        dbHelperPhone = new UserDatabase(this);

        // Initialize views
        phoneInput = findViewById(R.id.phoneInput);
        submitButton = findViewById(R.id.submitButton);
        noSMSButton = findViewById(R.id.noRegisterButton);

        // Handle submit button click
        submitButton.setOnClickListener(v -> {
            String phoneNumber = phoneInput.getText().toString();

            // Validate phone number
            if (isValidPhoneNumber(phoneNumber)) {
                registerNewPhone(phoneNumber);
                Toast.makeText(SMS_permissions.this, "Phone number registered successfully.", Toast.LENGTH_SHORT).show();

                // Navigate to MainActivity
                Intent intent = new Intent(SMS_permissions.this, MainActivity.class);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(SMS_permissions.this, "Please enter a valid 10-digit phone number.", Toast.LENGTH_SHORT).show();
            }
        });

        // Handle no SMS button click
        noSMSButton.setOnClickListener(v -> {
            Toast.makeText(SMS_permissions.this, "SMS permissions denied.", Toast.LENGTH_SHORT).show();

            // Navigate to MainActivity
            Intent intent = new Intent(SMS_permissions.this, MainActivity.class);
            startActivity(intent);
            finish();
        });
    }

    /***************************************
     * VALID PHONE NUMBER
     * method to check the the phone number
     * is equivalent to 10 digits
     * (currently does not support
     * dashes or parenthesis)
     **************************************/
    private boolean isValidPhoneNumber(String phoneNumber) {
        String regex = "^[0-9]{10}$";
        return phoneNumber.matches(regex);
    }

    /***************************************
     * REGISTER PHONE NUMBER
     * method to register a new phone number
     **************************************/
    private boolean registerNewPhone(String phoneNumber) {
        SQLiteDatabase db = dbHelperPhone.getWritableDatabase();

        // Insert new phone number
        ContentValues values = new ContentValues();
        values.put(UserDatabase.COLUMN_PHONE, phoneNumber);

        long newRowId = db.insert(UserDatabase.TABLE_NAME, null, values);
        return newRowId != -1;
    }
}
